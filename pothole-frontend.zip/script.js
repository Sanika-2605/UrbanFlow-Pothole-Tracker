// Global utility functions

// Show toast notification
function showToast(title, message, type = "info") {
  const toast = document.getElementById("toast")
  const titleEl = toast.querySelector(".toast-title")
  const messageEl = toast.querySelector(".toast-message")
  const iconEl = toast.querySelector(".toast-icon")

  titleEl.textContent = title
  messageEl.textContent = message

  // Set icon based on type
  iconEl.className = `toast-icon ${type}`
  switch (type) {
    case "success":
      iconEl.innerHTML = '<i class="fas fa-check-circle"></i>'
      break
    case "error":
      iconEl.innerHTML = '<i class="fas fa-exclamation-circle"></i>'
      break
    case "warning":
      iconEl.innerHTML = '<i class="fas fa-exclamation-triangle"></i>'
      break
    default:
      iconEl.innerHTML = '<i class="fas fa-info-circle"></i>'
  }

  // Show toast
  toast.classList.remove("hidden")
  toast.classList.add("show")

  // Hide after 5 seconds
  setTimeout(() => {
    toast.classList.remove("show")
    setTimeout(() => {
      toast.classList.add("hidden")
    }, 300)
  }, 5000)
}

// Tab functionality
function showTab(tabName) {
  // Hide all tab contents
  const tabContents = document.querySelectorAll(".tab-content")
  tabContents.forEach((content) => {
    content.classList.remove("active")
  })

  // Remove active class from all tab buttons
  const tabButtons = document.querySelectorAll(".tab-button")
  tabButtons.forEach((button) => {
    button.classList.remove("active")
  })

  // Show selected tab content
  const selectedTab = document.getElementById(`${tabName}-tab`)
  if (selectedTab) {
    selectedTab.classList.add("active")
  }

  // Add active class to clicked button
  const clickedButton = event?.target.closest(".tab-button")
  if (clickedButton) {
    clickedButton.classList.add("active")
  } else {
    // If called programmatically, find the button by tab name
    const buttons = document.querySelectorAll(".tab-button")
    buttons.forEach((button) => {
      if (button.textContent.toLowerCase().includes(tabName.toLowerCase())) {
        button.classList.add("active")
      }
    })
  }
}

// Format date
function formatDate(date) {
  return new Date(date).toLocaleDateString("en-IN", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

// Generate random ID
function generateId(prefix = "ID") {
  return `${prefix}${Math.random().toString(36).substr(2, 9).toUpperCase()}`
}

// Local storage helpers
function saveToStorage(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data))
    return true
  } catch (error) {
    console.error("Error saving to localStorage:", error)
    return false
  }
}

function getFromStorage(key, defaultValue = null) {
  try {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : defaultValue
  } catch (error) {
    console.error("Error reading from localStorage:", error)
    return defaultValue
  }
}

// Simulate API calls with delays
function simulateApiCall(data, delay = 1000) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(data)
    }, delay)
  })
}

// Validate form data
function validateForm(formElement) {
  const inputs = formElement.querySelectorAll("input[required], select[required], textarea[required]")
  let isValid = true

  inputs.forEach((input) => {
    if (!input.value.trim()) {
      input.style.borderColor = "#dc2626"
      isValid = false
    } else {
      input.style.borderColor = "#d1d5db"
    }
  })

  return isValid
}

// Format currency
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

// Debounce function
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

// Initialize common functionality
document.addEventListener("DOMContentLoaded", () => {
  // Add click handlers for tab buttons
  const tabButtons = document.querySelectorAll(".tab-button")
  tabButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const tabName = this.textContent.toLowerCase().trim()
      showTab(tabName)
    })
  })

  // Add form validation
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      if (!validateForm(this)) {
        e.preventDefault()
        showToast("Validation Error", "Please fill in all required fields", "error")
      }
    })
  })

  // Add smooth scrolling for anchor links
  const anchorLinks = document.querySelectorAll('a[href^="#"]')
  anchorLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Initialize tooltips
  const tooltipElements = document.querySelectorAll("[title]")
  tooltipElements.forEach((element) => {
    element.addEventListener("mouseenter", function () {
      // Simple tooltip implementation
      const tooltip = document.createElement("div")
      tooltip.className = "tooltip"
      tooltip.textContent = this.getAttribute("title")
      tooltip.style.cssText = `
                position: absolute;
                background: #333;
                color: white;
                padding: 0.5rem;
                border-radius: 0.25rem;
                font-size: 0.875rem;
                z-index: 10000;
                pointer-events: none;
                white-space: nowrap;
            `
      document.body.appendChild(tooltip)

      const rect = this.getBoundingClientRect()
      tooltip.style.left = rect.left + "px"
      tooltip.style.top = rect.top - tooltip.offsetHeight - 5 + "px"

      this._tooltip = tooltip
    })

    element.addEventListener("mouseleave", function () {
      if (this._tooltip) {
        document.body.removeChild(this._tooltip)
        this._tooltip = null
      }
    })
  })
})

// Utility functions for dashboard data
function generateMockReports(count = 10) {
  const locations = [
    "MG Road, Sector 14",
    "Park Street, Block A",
    "Main Avenue, Zone 3",
    "Central Plaza, Area 5",
    "Highway Junction, Mile 12",
    "Market Street, District 7",
    "School Road, Sector 9",
    "Hospital Lane, Block C",
  ]

  const statuses = ["pending", "approved", "in-progress", "completed"]
  const severities = ["low", "medium", "high"]

  const reports = []

  for (let i = 0; i < count; i++) {
    reports.push({
      id: `RPT${String(i + 1).padStart(3, "0")}`,
      location: locations[Math.floor(Math.random() * locations.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      severity: severities[Math.floor(Math.random() * severities.length)],
      date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toLocaleDateString(),
      timestamp: Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000,
    })
  }

  return reports.sort((a, b) => b.timestamp - a.timestamp)
}

// Initialize mock data if not exists
function initializeMockData() {
  if (!getFromStorage("userReports")) {
    saveToStorage("userReports", generateMockReports(5))
  }

  if (!getFromStorage("systemReports")) {
    saveToStorage("systemReports", generateMockReports(50))
  }
}

// Call initialization
initializeMockData()
