"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { BarChart3, MapPin, TrendingUp, Users, FileText, Calendar, DollarSign, Truck } from "lucide-react"
import { RoadDepartmentHeader } from "@/components/dashboard/road-department-header"
import { AnalyticsChart } from "@/components/charts/analytics-chart"

export default function RoadDepartmentDashboard() {
  const [activeTab, setActiveTab] = useState("analytics")

  const cityWideData = [
    {
      zone: "Zone A",
      totalPotholes: 45,
      repaired: 32,
      pending: 13,
      budget: 250000,
      spent: 180000,
    },
    {
      zone: "Zone B",
      totalPotholes: 67,
      repaired: 41,
      pending: 26,
      budget: 320000,
      spent: 245000,
    },
    {
      zone: "Zone C",
      totalPotholes: 38,
      repaired: 29,
      pending: 9,
      budget: 180000,
      spent: 145000,
    },
  ]

  const potholeData = [
    {
      id: "PH001",
      location: "MG Road, Sector 14",
      dimensions: { height: 15, width: 80, depth: 12 },
      severity: "high",
      status: "pending",
      reportedDate: "2024-01-15",
      estimatedRepair: "2-3 days",
      alertZone: "red",
    },
    {
      id: "PH002",
      location: "Park Street, Block A",
      dimensions: { height: 8, width: 45, depth: 6 },
      severity: "medium",
      status: "approved",
      reportedDate: "2024-01-14",
      estimatedRepair: "5-7 days",
      alertZone: "orange",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <RoadDepartmentHeader />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Road Department Dashboard</h1>
          <p className="text-gray-600">City-wide road infrastructure management and analytics</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="zones" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Zones
            </TabsTrigger>
            <TabsTrigger value="budget" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Budget
            </TabsTrigger>
            <TabsTrigger value="resources" className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              Resources
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="analytics" className="space-y-6">
            {/* City-wide Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Potholes</p>
                      <p className="text-3xl font-bold text-gray-900">150</p>
                    </div>
                    <MapPin className="h-8 w-8 text-blue-600" />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">Across all zones</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Repair Rate</p>
                      <p className="text-3xl font-bold text-green-600">68%</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-600" />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">+12% from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Teams</p>
                      <p className="text-3xl font-bold text-blue-600">8</p>
                    </div>
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">Currently deployed</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Budget Used</p>
                      <p className="text-3xl font-bold text-orange-600">76%</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-orange-600" />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">₹5.7L of ₹7.5L</p>
                </CardContent>
              </Card>
            </div>

            {/* Analytics Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Repair Trends</CardTitle>
                <CardDescription>Pothole reports and repairs over time</CardDescription>
              </CardHeader>
              <CardContent>
                <AnalyticsChart />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="zones" className="space-y-6">
            <div className="grid gap-6">
              {cityWideData.map((zone, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{zone.zone}</CardTitle>
                      <Badge variant="outline">
                        {Math.round((zone.repaired / zone.totalPotholes) * 100)}% Complete
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-4 gap-4 mb-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-gray-900">{zone.totalPotholes}</p>
                        <p className="text-sm text-gray-600">Total Potholes</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">{zone.repaired}</p>
                        <p className="text-sm text-gray-600">Repaired</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-orange-600">{zone.pending}</p>
                        <p className="text-sm text-gray-600">Pending</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-600">₹{(zone.spent / 1000).toFixed(0)}K</p>
                        <p className="text-sm text-gray-600">Spent</p>
                      </div>
                    </div>
                    <Progress value={(zone.repaired / zone.totalPotholes) * 100} className="mb-2" />
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>
                        Progress: {zone.repaired}/{zone.totalPotholes}
                      </span>
                      <span>
                        Budget: ₹{(zone.spent / 1000).toFixed(0)}K/₹{(zone.budget / 1000).toFixed(0)}K
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="budget" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Budget Allocation</CardTitle>
                  <CardDescription>Current fiscal year spending</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Materials &amp; Equipment</span>
                    <span className="font-medium">₹3.2L (45%)</span>
                  </div>
                  <Progress value={45} />

                  <div className="flex justify-between items-center">
                    <span>Labor Costs</span>
                    <span className="font-medium">₹1.8L (25%)</span>
                  </div>
                  <Progress value={25} />

                  <div className="flex justify-between items-center">
                    <span>Transportation</span>
                    <span className="font-medium">₹0.7L (10%)</span>
                  </div>
                  <Progress value={10} />

                  <div className="flex justify-between items-center">
                    <span>Emergency Repairs</span>
                    <span className="font-medium">₹1.4L (20%)</span>
                  </div>
                  <Progress value={20} />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Cost Analysis</CardTitle>
                  <CardDescription>Average repair costs by severity</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <div>
                      <p className="font-medium">High Severity</p>
                      <p className="text-sm text-gray-600">Deep potholes &gt; 10cm</p>
                    </div>
                    <span className="text-lg font-bold text-red-600">₹8,500</span>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium">Medium Severity</p>
                      <p className="text-sm text-gray-600">Moderate potholes 5-10cm</p>
                    </div>
                    <span className="text-lg font-bold text-orange-600">₹4,200</span>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                    <div>
                      <p className="font-medium">Low Severity</p>
                      <p className="text-sm text-gray-600">Surface damage &lt; 5cm</p>
                    </div>
                    <span className="text-lg font-bold text-yellow-600">₹1,800</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    Equipment Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span>Road Rollers</span>
                    <Badge variant="outline">3/4 Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Asphalt Mixers</span>
                    <Badge variant="outline">2/3 Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Repair Trucks</span>
                    <Badge variant="outline">6/8 Active</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Team Deployment
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span>Zone A Team</span>
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Zone B Team</span>
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Zone C Team</span>
                    <Badge className="bg-yellow-100 text-yellow-800">Standby</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Emergency Team</span>
                    <Badge className="bg-blue-100 text-blue-800">On Call</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Maintenance Schedule
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <p className="font-medium">Today</p>
                    <p className="text-gray-600">MG Road repairs (Zone A)</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">Tomorrow</p>
                    <p className="text-gray-600">Park Street inspection</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">This Week</p>
                    <p className="text-gray-600">3 scheduled repairs</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Comprehensive Reports</CardTitle>
                <CardDescription>Detailed analytics and performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-medium">Monthly Summary</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Reports Received:</span>
                        <span className="font-medium">127</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Repairs Completed:</span>
                        <span className="font-medium">89</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Average Response Time:</span>
                        <span className="font-medium">2.3 days</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Citizen Satisfaction:</span>
                        <span className="font-medium">4.2/5</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-medium">Export Options</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <FileText className="mr-2 h-4 w-4" />
                        Download Monthly Report
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Export Analytics Data
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <MapPin className="mr-2 h-4 w-4" />
                        Generate Zone Report
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
