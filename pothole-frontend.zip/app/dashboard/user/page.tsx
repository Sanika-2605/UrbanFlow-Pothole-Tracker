"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Camera, Video, MapPin, FileText, Phone, HelpCircle, MessageSquare } from "lucide-react"
import { UserDashboardHeader } from "@/components/dashboard/user-header"
import { ReportForm } from "@/components/forms/report-form"
import { ContactPage } from "@/components/pages/contact"
import { FAQPage } from "@/components/pages/faq"
import { FeedbackForm } from "@/components/forms/feedback-form"

export default function UserDashboard() {
  const [activeTab, setActiveTab] = useState("report")
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [isCapturing, setIsCapturing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const [reports] = useState([
    {
      id: "RPT001",
      location: "MG Road, Sector 14",
      status: "approved",
      date: "2024-01-15",
      severity: "high",
    },
    {
      id: "RPT002",
      location: "Park Street, Block A",
      status: "pending",
      date: "2024-01-14",
      severity: "medium",
    },
    {
      id: "RPT003",
      location: "Main Avenue, Zone 3",
      status: "in-progress",
      date: "2024-01-13",
      severity: "low",
    },
  ])

  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
          toast({
            title: "Location Access Granted",
            description: "Your location has been captured for accurate reporting",
          })
        },
        (error) => {
          toast({
            title: "Location Access Denied",
            description: "Please enable location services for accurate reporting",
            variant: "destructive",
          })
        },
      )
    }
  }

  const handleImageCapture = () => {
    getLocation()
    setIsCapturing(true)
    fileInputRef.current?.click()
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Simulate AI pothole detection
      setTimeout(() => {
        const isPotholeDetected = Math.random() > 0.3 // 70% chance of detection

        if (isPotholeDetected) {
          toast({
            title: "Pothole Detected!",
            description: "Report submitted successfully. Authorities have been notified.",
          })

          // Simulate notifications to authorities
          setTimeout(() => {
            toast({
              title: "Notification Sent",
              description: "Corporator and Road Department have been alerted about the pothole at your location.",
            })
          }, 2000)
        } else {
          toast({
            title: "No Pothole Detected",
            description: "The AI system didn't detect a pothole in this image. You can still submit a manual report.",
            variant: "destructive",
          })
        }
        setIsCapturing(false)
      }, 3000)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-orange-100 text-orange-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <UserDashboardHeader />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Citizen Dashboard</h1>
          <p className="text-gray-600">Report potholes and help make our roads safer</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="report" className="flex items-center gap-2">
              <Camera className="h-4 w-4" />
              Report
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              History
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Contact
            </TabsTrigger>
            <TabsTrigger value="faq" className="flex items-center gap-2">
              <HelpCircle className="h-4 w-4" />
              FAQ
            </TabsTrigger>
            <TabsTrigger value="feedback" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Feedback
            </TabsTrigger>
          </TabsList>

          <TabsContent value="report" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="h-5 w-5" />
                    Quick Report
                  </CardTitle>
                  <CardDescription>Capture a photo or video to report a pothole instantly</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button onClick={handleImageCapture} disabled={isCapturing} className="h-20 flex-col gap-2">
                      <Camera className="h-6 w-6" />
                      {isCapturing ? "Processing..." : "Take Photo"}
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex-col gap-2"
                      onClick={() => toast({ title: "Video capture coming soon!" })}
                    >
                      <Video className="h-6 w-6" />
                      Record Video
                    </Button>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4" />
                    {location ? "Location captured" : "Location access required"}
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    capture="environment"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Manual Report
                  </CardTitle>
                  <CardDescription>Fill out a detailed report form</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportForm />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Previous Reports</CardTitle>
                <CardDescription>Track the status of your submitted reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reports.map((report) => (
                    <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{report.id}</span>
                          <Badge className={getStatusColor(report.status)}>{report.status}</Badge>
                          <Badge className={getSeverityColor(report.severity)}>{report.severity}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {report.location}
                        </p>
                        <p className="text-xs text-gray-500">{report.date}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contact">
            <ContactPage />
          </TabsContent>

          <TabsContent value="faq">
            <FAQPage />
          </TabsContent>

          <TabsContent value="feedback">
            <Card>
              <CardHeader>
                <CardTitle>Share Your Feedback</CardTitle>
                <CardDescription>Help us improve PotholeGuard</CardDescription>
              </CardHeader>
              <CardContent>
                <FeedbackForm />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
