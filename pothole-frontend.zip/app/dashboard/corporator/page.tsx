"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  AlertTriangle,
  CheckCircle,
  Clock,
  MapPin,
  Ruler,
  Calendar,
  TrendingUp,
  FileText,
  Settings,
} from "lucide-react"
import { CorporatorHeader } from "@/components/dashboard/corporator-header"
import { PotholeMap } from "@/components/maps/pothole-map"

export default function CorporatorDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const potholeData = [
    {
      id: "PH001",
      location: "MG Road, Sector 14",
      dimensions: { height: 15, width: 80, depth: 12 },
      severity: "high",
      status: "pending",
      reportedDate: "2024-01-15",
      estimatedRepair: "2-3 days",
      alertZone: "red",
    },
    {
      id: "PH002",
      location: "Park Street, Block A",
      dimensions: { height: 8, width: 45, depth: 6 },
      severity: "medium",
      status: "approved",
      reportedDate: "2024-01-14",
      estimatedRepair: "5-7 days",
      alertZone: "orange",
    },
    {
      id: "PH003",
      location: "Main Avenue, Zone 3",
      dimensions: { height: 4, width: 25, depth: 3 },
      severity: "low",
      status: "in-progress",
      reportedDate: "2024-01-13",
      estimatedRepair: "1-2 weeks",
      alertZone: "yellow",
    },
  ]

  const getAlertZoneColor = (zone: string) => {
    switch (zone) {
      case "red":
        return "bg-red-100 text-red-800 border-red-200"
      case "orange":
        return "bg-orange-100 text-orange-800 border-orange-200"
      case "yellow":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <CorporatorHeader />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Corporator Dashboard</h1>
          <p className="text-gray-600">Monitor and manage pothole repairs in your constituency</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Reports
            </TabsTrigger>
            <TabsTrigger value="projects" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Projects
            </TabsTrigger>
            <TabsTrigger value="map" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Map View
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Reports</p>
                      <p className="text-3xl font-bold text-gray-900">127</p>
                    </div>
                    <FileText className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Pending Approval</p>
                      <p className="text-3xl font-bold text-yellow-600">23</p>
                    </div>
                    <Clock className="h-8 w-8 text-yellow-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">In Progress</p>
                      <p className="text-3xl font-bold text-blue-600">45</p>
                    </div>
                    <Settings className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Completed</p>
                      <p className="text-3xl font-bold text-green-600">59</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Alert Zones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Priority Alert Zones
                </CardTitle>
                <CardDescription>Potholes categorized by severity and repair urgency</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {potholeData.map((pothole) => (
                    <div key={pothole.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{pothole.id}</span>
                            <Badge className={`${getAlertZoneColor(pothole.alertZone)} border`}>
                              {pothole.alertZone.toUpperCase()} ZONE
                            </Badge>
                            <Badge className={getStatusColor(pothole.status)}>{pothole.status}</Badge>
                          </div>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {pothole.location}
                          </p>
                        </div>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Ruler className="h-4 w-4 text-gray-400" />
                          <span>H: {pothole.dimensions.height}cm</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Ruler className="h-4 w-4 text-gray-400" />
                          <span>W: {pothole.dimensions.width}cm</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Ruler className="h-4 w-4 text-gray-400" />
                          <span>D: {pothole.dimensions.depth}cm</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <span>ETA: {pothole.estimatedRepair}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Submitted Reports</CardTitle>
                  <CardDescription>New reports awaiting review</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600 mb-2">23</div>
                  <Progress value={65} className="mb-2" />
                  <p className="text-sm text-gray-600">65% increase from last week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Approved Reports</CardTitle>
                  <CardDescription>Reports approved for repair</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">45</div>
                  <Progress value={78} className="mb-2" />
                  <p className="text-sm text-gray-600">78% approval rate</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Working Projects</CardTitle>
                  <CardDescription>Active repair projects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-orange-600 mb-2">12</div>
                  <Progress value={45} className="mb-2" />
                  <p className="text-sm text-gray-600">45% completion rate</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="projects" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Active Repair Projects</CardTitle>
                <CardDescription>Monitor ongoing pothole repair work</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "MG Road Repair Phase 1", progress: 75, status: "On Track" },
                    { name: "Park Street Infrastructure", progress: 45, status: "Delayed" },
                    { name: "Main Avenue Resurfacing", progress: 90, status: "Near Completion" },
                  ].map((project, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium">{project.name}</h3>
                        <Badge variant={project.status === "On Track" ? "default" : "secondary"}>
                          {project.status}
                        </Badge>
                      </div>
                      <Progress value={project.progress} className="mb-2" />
                      <p className="text-sm text-gray-600">{project.progress}% Complete</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="map" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pothole Location Map</CardTitle>
                <CardDescription>Interactive map showing all reported potholes</CardDescription>
              </CardHeader>
              <CardContent>
                <PotholeMap potholes={potholeData} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
