import { LoginForm } from "@/components/auth/login-form"
import { Button } from "@/components/ui/button"
import { Shield, MapPin, AlertTriangle, Users } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">PotholeGuard</span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">
              Features
            </Link>
            <Link href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">
              Contact
            </Link>
            <Button variant="outline">Emergency: 1800-POTHOLE</Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl font-bold text-gray-900 leading-tight">
                  Smart Road Monitoring for
                  <span className="text-blue-600"> Safer Cities</span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Report potholes instantly with AI-powered detection. Real-time alerts to authorities ensure faster
                  repairs and safer roads for everyone.
                </p>
              </div>

              <div className="flex flex-wrap gap-4">
                <div className="flex items-center space-x-2 bg-white rounded-full px-4 py-2 shadow-sm">
                  <MapPin className="h-5 w-5 text-green-600" />
                  <span className="text-sm font-medium">GPS Location Tracking</span>
                </div>
                <div className="flex items-center space-x-2 bg-white rounded-full px-4 py-2 shadow-sm">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  <span className="text-sm font-medium">AI Pothole Detection</span>
                </div>
                <div className="flex items-center space-x-2 bg-white rounded-full px-4 py-2 shadow-sm">
                  <Users className="h-5 w-5 text-blue-600" />
                  <span className="text-sm font-medium">Multi-User Dashboard</span>
                </div>
              </div>

              <div className="pt-4">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg">
                  Get Started Today
                </Button>
              </div>
            </div>

            <div className="lg:pl-8">
              <LoginForm />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Comprehensive Road Safety Solution</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform connects citizens, corporators, and road departments for efficient pothole management
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 rounded-xl bg-blue-50 border border-blue-100">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Citizen Dashboard</h3>
              <p className="text-gray-600">
                Report potholes with photos, track previous reports, and access emergency contacts
              </p>
            </div>

            <div className="text-center p-6 rounded-xl bg-green-50 border border-green-100">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Corporator Portal</h3>
              <p className="text-gray-600">
                Monitor pothole severity, manage repair schedules, and track project progress
              </p>
            </div>

            <div className="text-center p-6 rounded-xl bg-purple-50 border border-purple-100">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Road Department</h3>
              <p className="text-gray-600">
                Comprehensive analytics, resource allocation, and city-wide road maintenance
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Contact Section */}
      <section id="contact" className="py-16 bg-red-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Emergency Contacts</h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold text-lg mb-2">Road Emergency</h3>
              <p className="text-2xl font-bold text-red-600">1800-POTHOLE</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold text-lg mb-2">Municipal Office</h3>
              <p className="text-2xl font-bold text-blue-600">1800-MUNICIPAL</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold text-lg mb-2">Traffic Police</h3>
              <p className="text-2xl font-bold text-green-600">100</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Shield className="h-8 w-8 text-blue-400" />
            <span className="text-2xl font-bold">PotholeGuard</span>
          </div>
          <p className="text-gray-400 mb-4">Making roads safer, one report at a time.</p>
          <p className="text-sm text-gray-500">© 2024 PotholeGuard. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
