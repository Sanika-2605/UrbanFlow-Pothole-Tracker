"use client"
import { TrendingUp } from "lucide-react"

export function AnalyticsChart() {
  const monthlyData = [
    { month: "Jan", reports: 45, repairs: 38 },
    { month: "Feb", reports: 52, repairs: 41 },
    { month: "Mar", reports: 38, repairs: 35 },
    { month: "Apr", reports: 61, repairs: 48 },
    { month: "May", reports: 55, repairs: 52 },
    { month: "Jun", reports: 67, repairs: 59 },
  ]

  const maxValue = Math.max(...monthlyData.flatMap((d) => [d.reports, d.repairs]))

  return (
    <div className="space-y-4">
      {/* Chart */}
      <div className="h-64 flex items-end justify-between space-x-2 border-b border-gray-200 pb-4">
        {monthlyData.map((data, index) => (
          <div key={index} className="flex-1 flex flex-col items-center space-y-2">
            <div className="w-full flex justify-center space-x-1">
              <div
                className="bg-blue-500 rounded-t w-4"
                style={{ height: `${(data.reports / maxValue) * 200}px` }}
                title={`Reports: ${data.reports}`}
              ></div>
              <div
                className="bg-green-500 rounded-t w-4"
                style={{ height: `${(data.repairs / maxValue) * 200}px` }}
                title={`Repairs: ${data.repairs}`}
              ></div>
            </div>
            <span className="text-xs text-gray-600">{data.month}</span>
          </div>
        ))}
      </div>

      {/* Legend and Stats */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span className="text-sm">Reports Received</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-sm">Repairs Completed</span>
          </div>
        </div>

        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-1 text-green-600">
            <TrendingUp className="h-4 w-4" />
            <span>+12% repairs</span>
          </div>
          <div className="flex items-center space-x-1 text-blue-600">
            <TrendingUp className="h-4 w-4" />
            <span>+8% reports</span>
          </div>
        </div>
      </div>
    </div>
  )
}
