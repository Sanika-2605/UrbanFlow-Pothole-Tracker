import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown, HelpCircle } from "lucide-react"

export function FAQPage() {
  const faqs = [
    {
      question: "How do I report a pothole?",
      answer:
        "You can report a pothole by taking a photo using our app, which will automatically detect the pothole and capture your location. Alternatively, you can fill out the manual report form with details about the location and severity.",
    },
    {
      question: "How long does it take for potholes to be repaired?",
      answer:
        "Repair times depend on severity: High severity (red zone) - 2-3 days, Medium severity (orange zone) - 5-7 days, Low severity (yellow zone) - 1-2 weeks. Emergency repairs are prioritized and completed within 24 hours.",
    },
    {
      question: "Can I track the status of my report?",
      answer:
        "Yes! You can view all your previous reports in the 'History' tab of your dashboard. Each report shows its current status: pending, approved, in-progress, or completed.",
    },
    {
      question: "What information do I need to provide when reporting?",
      answer:
        "For the best results, provide: exact location or nearby landmarks, photos or videos of the pothole, estimated size/depth, and any safety concerns. Our AI system can automatically detect potholes from photos.",
    },
    {
      question: "Is my location data safe?",
      answer:
        "Yes, we only use your location to accurately pinpoint pothole locations for repair teams. Location data is encrypted and only shared with authorized municipal authorities for repair purposes.",
    },
    {
      question: "What happens after I submit a report?",
      answer:
        "After submission, your report is automatically sent to the relevant corporator and road department. You'll receive notifications about status updates, and repair teams will be dispatched based on priority.",
    },
    {
      question: "Can I report potholes anonymously?",
      answer:
        "While we require basic contact information for verification, your personal details are kept confidential and only used for communication about your specific reports.",
    },
    {
      question: "What if the pothole isn't repaired within the estimated time?",
      answer:
        "You can follow up on your report through the app or contact our support team. We also have an escalation process for overdue repairs that automatically alerts higher authorities.",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HelpCircle className="h-5 w-5" />
          Frequently Asked Questions
        </CardTitle>
        <CardDescription>Find answers to common questions about PotholeGuard</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <Collapsible key={index}>
              <CollapsibleTrigger className="flex w-full items-center justify-between rounded-lg border p-4 text-left hover:bg-gray-50">
                <span className="font-medium">{faq.question}</span>
                <ChevronDown className="h-4 w-4 transition-transform duration-200" />
              </CollapsibleTrigger>
              <CollapsibleContent className="px-4 pb-4 pt-2">
                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
