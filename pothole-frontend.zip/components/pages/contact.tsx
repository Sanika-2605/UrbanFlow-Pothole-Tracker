import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Phone, Mail, MapPin, Clock, AlertTriangle } from "lucide-react"

export function ContactPage() {
  const emergencyContacts = [
    {
      title: "Road Emergency Hotline",
      number: "1800-POTHOLE",
      description: "24/7 emergency road hazard reporting",
      icon: AlertTriangle,
      color: "text-red-600",
    },
    {
      title: "Municipal Corporation",
      number: "1800-MUNICIPAL",
      description: "General municipal services and complaints",
      icon: Phone,
      color: "text-blue-600",
    },
    {
      title: "Traffic Police",
      number: "100",
      description: "Traffic emergencies and road safety",
      icon: Phone,
      color: "text-green-600",
    },
  ]

  const offices = [
    {
      name: "City Municipal Corporation",
      address: "123 Civic Center, Main Road, City - 400001",
      phone: "+91 22 2345 6789",
      email: "info@citymunicipal.gov.in",
      hours: "Mon-Fri: 9:00 AM - 6:00 PM",
    },
    {
      name: "Road Development Department",
      address: "456 Infrastructure Building, Sector 5, City - 400002",
      phone: "+91 22 3456 7890",
      email: "roads@citydev.gov.in",
      hours: "Mon-Sat: 8:00 AM - 5:00 PM",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Emergency Contacts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            Emergency Contacts
          </CardTitle>
          <CardDescription>For immediate road safety concerns and emergencies</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            {emergencyContacts.map((contact, index) => (
              <div key={index} className="border rounded-lg p-4 text-center">
                <contact.icon className={`h-8 w-8 mx-auto mb-2 ${contact.color}`} />
                <h3 className="font-semibold mb-1">{contact.title}</h3>
                <p className={`text-2xl font-bold mb-2 ${contact.color}`}>{contact.number}</p>
                <p className="text-sm text-gray-600">{contact.description}</p>
                <Button className="mt-3 w-full" variant="outline">
                  <Phone className="mr-2 h-4 w-4" />
                  Call Now
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Office Locations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Office Locations
          </CardTitle>
          <CardDescription>Visit our offices for in-person assistance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {offices.map((office, index) => (
              <div key={index} className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-3">{office.name}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-gray-400 mt-0.5" />
                    <span>{office.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <span>{office.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-gray-400" />
                    <span>{office.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gray-400" />
                    <span>{office.hours}</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button size="sm" variant="outline" className="flex-1">
                    <Phone className="mr-2 h-3 w-3" />
                    Call
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <Mail className="mr-2 h-3 w-3" />
                    Email
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
