"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { MapPin, Send } from "lucide-react"

export function ReportForm() {
  const [formData, setFormData] = useState({
    location: "",
    description: "",
    severity: "",
    landmark: "",
  })
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Report Submitted!",
      description: "Your pothole report has been submitted successfully.",
    })
    setFormData({ location: "", description: "", severity: "", landmark: "" })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="location">Location</Label>
        <div className="relative">
          <Input
            id="location"
            placeholder="Enter street address or area"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            required
          />
          <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="landmark">Nearby Landmark</Label>
        <Input
          id="landmark"
          placeholder="e.g., Near City Mall, Opposite Bank"
          value={formData.landmark}
          onChange={(e) => setFormData({ ...formData, landmark: e.target.value })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="severity">Severity Level</Label>
        <Select onValueChange={(value) => setFormData({ ...formData, severity: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low">Low - Minor surface damage</SelectItem>
            <SelectItem value="medium">Medium - Noticeable hole</SelectItem>
            <SelectItem value="high">High - Deep/dangerous pothole</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Describe the pothole condition, size, and any safety concerns..."
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          rows={3}
        />
      </div>

      <Button type="submit" className="w-full">
        <Send className="mr-2 h-4 w-4" />
        Submit Report
      </Button>
    </form>
  )
}
