"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Smartphone, Shield } from "lucide-react"
import { useRouter } from "next/navigation"

export function LoginForm() {
  const [step, setStep] = useState<"login" | "otp">("login")
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    userType: "",
    otp: "",
  })
  const { toast } = useToast()
  const router = useRouter()

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name || !formData.phone || !formData.userType) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    // Simulate OTP sending
    toast({
      title: "OTP Sent!",
      description: `Verification code sent to ${formData.phone}`,
    })
    setStep("otp")
  }

  const handleOTPVerification = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.otp === "123456") {
      toast({
        title: "Login Successful!",
        description: "Welcome to PotholeGuard",
      })

      // Redirect based on user type
      switch (formData.userType) {
        case "citizen":
          router.push("/dashboard/user")
          break
        case "corporator":
          router.push("/dashboard/corporator")
          break
        case "road-department":
          router.push("/dashboard/road-department")
          break
      }
    } else {
      toast({
        title: "Invalid OTP",
        description: "Please enter the correct verification code",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto glass-effect">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-blue-600 rounded-full">
            <Shield className="h-6 w-6 text-white" />
          </div>
        </div>
        <CardTitle className="text-2xl font-bold">
          {step === "login" ? "Join PotholeGuard" : "Verify Your Phone"}
        </CardTitle>
        <CardDescription>
          {step === "login" ? "Enter your details to get started" : "Enter the 6-digit code sent to your phone"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {step === "login" ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your full name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="userType">I am a</Label>
              <Select onValueChange={(value) => setFormData({ ...formData, userType: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="citizen">Citizen</SelectItem>
                  <SelectItem value="corporator">Corporator</SelectItem>
                  <SelectItem value="road-department">Road Department Official</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
              <Smartphone className="mr-2 h-4 w-4" />
              Send OTP
            </Button>
          </form>
        ) : (
          <form onSubmit={handleOTPVerification} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="otp">Verification Code</Label>
              <Input
                id="otp"
                type="text"
                placeholder="Enter 6-digit code"
                maxLength={6}
                value={formData.otp}
                onChange={(e) => setFormData({ ...formData, otp: e.target.value })}
                className="text-center text-lg tracking-widest"
                required
              />
            </div>

            <p className="text-sm text-gray-600 text-center">Code sent to {formData.phone}</p>

            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
              Verify & Login
            </Button>

            <Button type="button" variant="ghost" className="w-full" onClick={() => setStep("login")}>
              Back to Login
            </Button>

            <p className="text-xs text-center text-gray-500">Demo OTP: 123456</p>
          </form>
        )}
      </CardContent>
    </Card>
  )
}
