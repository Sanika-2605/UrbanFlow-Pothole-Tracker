"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Navigation } from "lucide-react"

interface Pothole {
  id: string
  location: string
  alertZone: string
  severity: string
  status: string
}

interface PotholeMapProps {
  potholes: Pothole[]
}

export function PotholeMap({ potholes }: PotholeMapProps) {
  const getZoneColor = (zone: string) => {
    switch (zone) {
      case "red":
        return "bg-red-500"
      case "orange":
        return "bg-orange-500"
      case "yellow":
        return "bg-yellow-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="space-y-4">
      {/* Map Placeholder */}
      <div className="relative h-96 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
        <div className="text-center">
          <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-500 font-medium">Interactive Map</p>
          <p className="text-sm text-gray-400">Pothole locations will be displayed here</p>
        </div>

        {/* Simulated map markers */}
        <div className="absolute top-20 left-32">
          <div className="w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg"></div>
        </div>
        <div className="absolute top-40 right-28">
          <div className="w-4 h-4 bg-orange-500 rounded-full border-2 border-white shadow-lg"></div>
        </div>
        <div className="absolute bottom-24 left-20">
          <div className="w-4 h-4 bg-yellow-500 rounded-full border-2 border-white shadow-lg"></div>
        </div>
      </div>

      {/* Map Legend */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium">Alert Zones:</span>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-xs">High Priority</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
            <span className="text-xs">Medium Priority</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span className="text-xs">Low Priority</span>
          </div>
        </div>
        <Badge variant="outline" className="flex items-center gap-1">
          <Navigation className="h-3 w-3" />
          Live Updates
        </Badge>
      </div>

      {/* Pothole List */}
      <div className="grid gap-3">
        {potholes.map((pothole) => (
          <Card key={pothole.id} className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${getZoneColor(pothole.alertZone)}`}></div>
                <div>
                  <p className="font-medium text-sm">{pothole.id}</p>
                  <p className="text-xs text-gray-600">{pothole.location}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="text-xs">
                  {pothole.severity}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {pothole.status}
                </Badge>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
